import React from "react";
import { FaHeart } from "react-icons/fa";

function TaskItem({ task, toggleLike }) {
  return (
    <div style={{ margin: "10px 0" }}>
      <span>{task.text}</span>
      <FaHeart
        onClick={() => toggleLike(task.id)}
        style={{
          marginLeft: "10px",
          cursor: "pointer",
          color: task.liked ? "red" : "gray",
        }}
      />
    </div>
  );
}

export default TaskItem;
