import React from "react";
import TaskItem from "./TaskItem";

function TaskList({ tasks, toggleLike }) {
  return (
    <div>
      {tasks.map((task) => (
        <TaskItem key={task.id} task={task} toggleLike={toggleLike} />
      ))}
    </div>
  );
}

export default TaskList;
