import React, { useState } from "react";
import TaskList from "./TaskList";

function App() {
  const [tasks, setTasks] = useState([
    { id: 1, text: "Изучить React", liked: false },
    { id: 2, text: "Сделать проект", liked: false },
    { id: 3, text: "Сдать задание", liked: false },
  ]);

  const toggleLike = (id) => {
    setTasks(
      tasks.map((task) =>
        task.id === id ? { ...task, liked: !task.liked } : task,
      ),
    );
  };

  return (
    <div style={{ padding: "20px" }}>
      <h1>Список задач</h1>
      <TaskList tasks={tasks} toggleLike={toggleLike} />
    </div>
  );
}

export default App;
