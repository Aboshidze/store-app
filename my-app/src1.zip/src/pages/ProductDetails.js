import React, { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import Loader from "../components/Loader";

function ProductDetails() {
  const { id } = useParams();
  const [product, setProduct] = useState(null);

  useEffect(() => {
    fetch(`https://dummyjson.com/products/${id}`)
      .then((res) => res.json())
      .then((data) => setProduct(data));
  }, [id]);

  if (!product) return <Loader />;

  return (
    <div>
      <h1>{product.title}</h1>
      <p>{product.description}</p>
      <h3>Цена: ${product.price}</h3>
    </div>
  );
}

export default ProductDetails;
